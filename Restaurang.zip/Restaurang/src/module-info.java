module Restaurang {
	requires java.desktop;
}